'use strict';

module.exports = {
  GoogleAnalytics: {
    options: {
      title: "Google Analytics",
      message: "Change your Analytics ID !!\nIf you didn't change, correct it pls !!"
    }
  }
};