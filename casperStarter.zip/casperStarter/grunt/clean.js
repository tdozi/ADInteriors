'use strict';

module.exports = {
	release: ['<%= dirs.release %>'],
	staging: ['<%= dirs.staging %>'],
	sass: ['<%= dirs.release %>/css/*scss']
};